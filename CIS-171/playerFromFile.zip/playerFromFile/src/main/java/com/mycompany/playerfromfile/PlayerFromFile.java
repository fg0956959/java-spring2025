/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.playerfromfile;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Iterable;




/**
 *
 * @author Franklin Gainer
 * 
 */

class player
    {
        private String initials;//private feilds
        private Integer score;
        
        public player(String Playername, Integer Playerscore)//constructor for initializing feilds
        {
            this.initials = Playername;
            this.score = Playerscore;
        }
        
        public String getPlayerInitials()//getters and setters for player feilds
        {
            return initials;
        }
        
        public void setPlayerInitials(String PlayerName)
        {
            this.initials = PlayerName;
        }
        
        public Integer getPlayerScore()
        {
            return score;
        }
        
        public void setPlayerScore(Integer PlayerScore)
        {
            this.score = PlayerScore;
        }
        
        
    }
public class PlayerFromFile {    
    
    
    public static void main(String[] args) {
        String WorkingDir = System.getProperty("User.dir");
        String filePath = WorkingDir + "\\src\\main\\java\\com\\mycompany\\PlayerData.cvs";
        List<List<player>> playerRecords = new ArrayList<>();
        
        try
        {
            PrintWriter writer = new PrintWriter(new FileWriter(filePath,true));
            
            player player1 = new player("aaa", 10000000);
            player player12 = new player("aaa", 9000000);
            player player3 = new player("bbb", 8000000);
            player player4 = new player("ccc", 7000000);
            player player5 = new player("ddd", 6000000);
            player player6 = new player("eee", 5000000);
            player player7 = new player("fff",40000000);
            player player8 = new player("ggg", 3000000);
            player player9 = new player("hhh", 2000000);
            player player10 = new player("iii", 1000000);
            
            for(List<player> playerIritirat: playerRecords)
            {
                playerRecords.add(playerIritirat);
                System.out.println(playerIritirat.toString());
            }
            
            
        }
      catch(IOException e)
      {
          System.out.println(e.getMessage());
      }
    }
}
